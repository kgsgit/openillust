# Openillust
Skeleton structure for project setup.